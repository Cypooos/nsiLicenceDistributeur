Projet de base de donnée "LicenceDistributeur" par Cyprien BOUROTTE, Angela QUENUM et Laetitia SALE.



Installation : 
 - Python 3
 - Module PyQt5 et pyqtgraph

Lancer main.py
Si les modules ne sont pas détecté, une installation automatique sera tentée.



Fonctionalitées :
 - Création de licences sécurisé par hash + vérification
 - Management de la base de donnée (ajouter / modifier / supprimmer)
 - Graphique
 - Calul d'une réduction optimisé selon la moyenne des avis
 - Création de compte + mot de passe sécurisé
 - Statistique sur les licences / prets